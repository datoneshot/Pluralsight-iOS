//
//  LogInField.swift
//  CustomControls
//
//  Created by Jordan Morgan on 5/28/16.
//  Copyright © 2016 Dreaming In Binary. All rights reserved.
//

import UIKit

enum FieldType
{
    case Email
    case Password
}

class LogInField: UIView
{
    //MARK: Properties
    var type:FieldType = .Email
    
    //MARK: Initializers
    init(frame: CGRect, type:FieldType)
    {
        self.type = type
        super.init(frame: frame)
    }
    
    override init(frame: CGRect)
    {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    }
}
