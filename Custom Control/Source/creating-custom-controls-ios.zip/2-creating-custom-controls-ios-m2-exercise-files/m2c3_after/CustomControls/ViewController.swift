//
//  ViewController.swift
//  CustomControls
//
//  Created by Jordan Morgan on 2/28/16.
//  Copyright © 2016 Dreaming In Binary. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var imgAvatar: UIImageView!
    @IBOutlet weak var btnLogIn: UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.btnLogIn.layer.cornerRadius = 4
    }
}

