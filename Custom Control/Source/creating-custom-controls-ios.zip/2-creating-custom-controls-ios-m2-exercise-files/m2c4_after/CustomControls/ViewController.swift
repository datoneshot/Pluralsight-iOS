//
//  ViewController.swift
//  CustomControls
//
//  Created by Jordan Morgan on 2/28/16.
//  Copyright © 2016 Dreaming In Binary. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var imgAvatar: UIImageView!
    @IBOutlet weak var btnLogIn: UIButton!
    
    var inputEmail:LogInField!
    var inputPassword:LogInField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.btnLogIn.layer.cornerRadius = 4
        
        self.inputEmail = LogInField(frame: CGRectMake(self.view.width/2 - 100, self.view.centerY - 20, 200, 40), type:.Email)
        self.view.addSubview(inputEmail)
        
        self.inputPassword = LogInField(frame: CGRectMake(self.view.width/2 - 100, self.view.centerY + 20, 200, 40), type: .Password)
        self.view.addSubview(inputPassword)
        
    }
    
    override func viewWillLayoutSubviews()
    {
        self.inputEmail.frame = CGRectMake(self.view.width/2 - 100, self.view.centerY - 20, 200, 40)
        self.inputPassword.frame = CGRectMake(self.view.width/2 - 100, self.view.centerY + 20, 200, 40)
    }
}

