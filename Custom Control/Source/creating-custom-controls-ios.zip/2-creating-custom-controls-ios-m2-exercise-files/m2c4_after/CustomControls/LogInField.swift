//
//  LogInField.swift
//  CustomControls
//
//  Created by Jordan Morgan on 5/28/16.
//  Copyright © 2016 Dreaming In Binary. All rights reserved.
//

import UIKit

enum FieldType
{
    case Email
    case Password
}

class LogInField: UIView
{
    //MARK: Properties
    var type:FieldType = .Email
    
    private let topLbl:UILabel = UILabel()
    private let inputTxtField:UITextField = UITextField()
    private let bottomLineView:UIView = UIView()
    
    //MARK: Initializers
    init(frame: CGRect, type:FieldType)
    {
        self.type = type
        super.init(frame: frame)
        self.setupControls()
    }
    
    override init(frame: CGRect)
    {
        super.init(frame: frame)
        self.setupControls()
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        self.setupControls()
    }
    
    //MARK: UI Methods
    private func setupControls()
    {
        self.addSubview(self.topLbl)
        self.topLbl.frame = CGRectMake(0, self.boundsHeight/2, self.boundsWidth, 20)
        self.topLbl.alpha = 0
        self.topLbl.text = self.type == .Email ? "Email" : "Password"
        self.topLbl.textAlignment = .Left
        self.topLbl.textColor = UIColor.blueColor()
        self.topLbl.font = UIFont.systemFontOfSize(12)
        
        self.addSubview(self.bottomLineView)
        self.bottomLineView.backgroundColor = UIColor.lightGrayColor()
        self.bottomLineView.frame = CGRectMake(0, self.boundsHeight, self.boundsWidth, 1)
        
        self.addSubview(self.inputTxtField)
        self.inputTxtField.placeholder = self.type == .Email ? "Email" : "Password"
        self.inputTxtField.secureTextEntry = self.type == .Password
        self.inputTxtField.textAlignment = .Left
        self.inputTxtField.frame = CGRectMake(0, 19, self.boundsWidth, 20)
    }
}
