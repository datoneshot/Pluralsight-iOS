//
//  LogInField.swift
//  CustomControls
//
//  Created by Jordan Morgan on 5/28/16.
//  Copyright © 2016 Dreaming In Binary. All rights reserved.
//

import UIKit

enum FieldType
{
    case Email
    case Password
}

@IBDesignable
class LogInField: UIView, UITextFieldDelegate
{
    //MARK: Properties
    @IBInspectable var type:FieldType = .Email
    @IBInspectable var useForEmail:Bool = true
    private let topLbl:UILabel = UILabel()
    private let inputTxtField:UITextField = UITextField()
    private let bottomLineView:UIView = UIView()
    
    //MARK: Initializers
    init(frame: CGRect, type:FieldType)
    {
        self.type = type
        super.init(frame: frame)
        self.setupControls()
    }
    
    override init(frame: CGRect)
    {
        super.init(frame: frame)
        self.setupControls()
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        self.setupControls()
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        self.type = self.useForEmail ? .Email : .Password
        self.setupControls()
    }
    
    override func intrinsicContentSize() -> CGSize
    {
        return CGSizeMake(200, 40)
    }
    
    //MARK: UI Methods
    private func setupControls()
    {
        self.addSubview(self.topLbl)
        self.topLbl.frame = CGRectMake(0, self.boundsHeight/2, self.boundsWidth, 20)
        self.topLbl.alpha = 0
        self.topLbl.text = self.type == .Email ? "Email" : "Password"
        self.topLbl.textAlignment = .Left
        self.topLbl.textColor = UIColor.blueColor()
        self.topLbl.font = UIFont.systemFontOfSize(12)
        
        self.addSubview(self.bottomLineView)
        self.bottomLineView.backgroundColor = UIColor.lightGrayColor()
        self.bottomLineView.frame = CGRectMake(0, self.boundsHeight, self.boundsWidth, 1)
        
        self.addSubview(self.inputTxtField)
        self.inputTxtField.delegate = self
        self.inputTxtField.placeholder = self.type == .Email ? "Email" : "Password"
        self.inputTxtField.secureTextEntry = self.type == .Password
        self.inputTxtField.textAlignment = .Left
        self.inputTxtField.frame = CGRectMake(0, 19, self.boundsWidth, 20)
        
        self.inputTxtField.addTarget(self, action: #selector(LogInField.checkTopLabel(_:)), forControlEvents: .EditingChanged)
    }
    
    
    //MARK: Invalid Input Animation
    private func animateInvalidEmailInput()
    {
        self.topLbl.textColor = UIColor.redColor()
        
        CATransaction.begin()
        CATransaction.setCompletionBlock {
            self.topLbl.textColor = UIColor.lightGrayColor()
        }
        
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.05
        animation.fromValue = NSValue(CGPoint: CGPointMake(self.topLbl.centerX - 8, self.topLbl.centerY))
        animation.toValue = NSValue(CGPoint: CGPointMake(self.topLbl.centerX + 8, self.topLbl.centerY))
        animation.repeatCount = 5
        animation.autoreverses = true
        self.topLbl.layer.addAnimation(animation, forKey: "position")
        
        CATransaction.commit()
    }
    
    func executeClosureIfEmailIsValid(onValidCompletion:()->())
    {
        guard let text = self.inputTxtField.text where text.characters.count > 0 else
        {
            return
        }
        
        do
        {
            let emailRegex = try NSRegularExpression(pattern: "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$", options: .CaseInsensitive)
            
            if emailRegex.firstMatchInString(text, options: [], range: NSMakeRange(0, text.characters.count)) != nil
            {
                onValidCompletion()
            }
            else
            {
                self.animateInvalidEmailInput()
            }
        }
        catch
        {
            self.animateInvalidEmailInput()
        }
    }
    
    //MARK: UITextField Delegate
    func textFieldDidBeginEditing(textField: UITextField)
    {
        if textField.text?.characters.count > 0
        {
            self.topLbl.textColor = UIColor.blueColor()
        }
    }
    
    func textFieldDidEndEditing(textField: UITextField)
    {
        if textField.text?.characters.count > 0
        {
            self.topLbl.textColor = UIColor.lightGrayColor()
        }
        else
        {
            UIView.animateWithDuration(0.25, animations: {
                self.topLbl.alpha = 0
            }, completion: { done in
                self.topLbl.textColor = UIColor.blueColor()
                self.topLbl.frame = CGRectMake(0, self.boundsHeight/2, self.boundsWidth, 1)
            })
        }
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        self.inputTxtField.endEditing(true)
        return false
    }
    
    func checkTopLabel(sender:UITextField!)
    {
        guard sender.text?.characters.count > 0 else
        {
            return
        }
        
        UIView.animateWithDuration(0.5, animations: {
            self.topLbl.alpha = 1
            self.topLbl.frame = CGRectMake(0, 2, self.boundsWidth, 20)
        })
    }
}
